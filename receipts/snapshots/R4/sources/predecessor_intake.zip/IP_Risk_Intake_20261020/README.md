# IP-20261020-001 — Bounded Candidate Evidence Handoff

Contents:
- Original user-provided PDF (exact bytes), seven-page text extraction `source_pages.jsonl`.
- `evidence_manifest.json`: source identities, GitHub blob IDs and explicit null states.
- `IP_RISK_ANALYSIS.md`: detailed noncanonical IP risk analysis.
- `risk_register.csv`, `nodes.csv`, `higher_order_links.csv` and `higher_order_paths.csv`: 25 proposed edges and 26 computed 2–3-hop candidate chains (no runtime transfer established).
- `INTEGRITY.sha256`: exact SHA-256 of bundle member bytes excluding this list.

**NOT completed:** import of complete source-code trees, protected datasets, live Cognee/BAND graph, signature verification, root computation, freedom-to-operate search, or legal clearance. All graph/claims are intake candidates and cannot be admitted directly to canonical projects.

Licenses/terms for external sources must be checked against their versions when actually used. This bundle is a non-public research handoff, not a source-code redistribution package.
